﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriparaSE
{
    internal class Avatar
    {
        public string Name { get; set; }
        public int EyeType  { get; set; }
        public int SkinColor  { get; set; }
        public int HairStyle  { get; set; }
        public int HairColor  { get; set; }
        public int EyeColor  { get; set; }
        public int Glass  { get; set; }
        public int MakeUp  { get; set; }
        public int Top  { get; set; }
        public int Bottom  { get; set; }
        public int Shoot  { get; set; }
        public int Head  { get; set; }
    }
}
