﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriparaSE
{
    internal class Misc
    {
        public int Money { get; set; }
        public int IdolRank { get; set; }
        public int Iine { get; set; }
    }
}
